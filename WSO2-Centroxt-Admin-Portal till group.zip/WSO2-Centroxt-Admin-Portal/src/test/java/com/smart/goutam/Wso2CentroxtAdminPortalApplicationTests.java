package com.smart.goutam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Wso2CentroxtAdminPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
