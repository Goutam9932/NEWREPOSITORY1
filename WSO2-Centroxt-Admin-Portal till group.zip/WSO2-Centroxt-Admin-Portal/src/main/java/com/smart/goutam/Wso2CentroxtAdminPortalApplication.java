package com.smart.goutam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Wso2CentroxtAdminPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(Wso2CentroxtAdminPortalApplication.class, args);
	}

}
