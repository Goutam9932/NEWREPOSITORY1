 document.addEventListener('DOMContentLoaded', () => {
            const searchInput = document.getElementById('search-users');
            const userList = document.querySelector('.user-list');

            searchInput.addEventListener('input', () => {
                const searchValue = searchInput.value.toLowerCase();
                const users = userList.querySelectorAll('li');

                users.forEach(user => {
                    const userName = user.textContent.toLowerCase();
                    if (userName.includes(searchValue)) {
                        user.style.display = '';
                    } else {
                        user.style.display = 'none';
                    }
                });
            });

            const cancelButton = document.querySelector('.cancel-btn');
            cancelButton.addEventListener('click', () => {
                alert('Cancel button clicked');
            });
        });

        function showStep(step) {
            const steps = document.querySelectorAll('.modal-step');
            steps.forEach((stepDiv, index) => {
                stepDiv.style.display = (index + 1 === step) ? 'block' : 'none';
            });
        }
        
        
        